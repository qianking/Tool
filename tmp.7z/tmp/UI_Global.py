from enum import Enum
from PySide6.QtCore import Qt

class Text_Color(Enum):
    black = Qt.black
    darkYellow = Qt.darkYellow
    red = Qt.red
    blue = Qt.blue
    darkGreen = Qt.darkGreen

class Message_Type(Enum):
    information = 'information'
    warning = 'warning'
    critical = 'critical'
    
class UI_SIGNALS():
    def __init__(self):
        self.signal = None
        self.color = Text_Color
        self.type = Message_Type
    
    def send_data(self, data:dict):
        if self.signal:
            self.signal.data.emit(data)
        
    def send_messagebox(self, title, content, type = 'information'):
        if self.signal:
            self.signal.messagebox.emit((title, content, type))
    
    

class _Variable():
    UI_Signal = UI_SIGNALS()
    UI_Color = Text_Color
    UI_Type = Message_Type

class Global(_Variable):
    """
    整個程式的全域變數，如果需要就import這個函數
    """
    _instance = None

    def __new__(cls, *args, **kwargs): 
        if cls._instance is None: 
            cls._instance = super().__new__(cls)
        return cls._instance