import re
import os 
import sys
import traceback
from copy import deepcopy
from UI_Global import Global

file_path = r"C:\Users\andy_chien\Downloads\tmp\tmp-Col-Rebar-2F-C201.txt"

def debug(func):
    def warpper(*args, **wargs):
        try:
            func(*args, **wargs)
        except Exception as ex:
            error_class = ex.__class__.__name__ #取得錯誤類型
            detail = ex.args[0] #取得詳細內容
            cl, exc, tb = sys.exc_info() #取得Call Stack
            lastCallStack = traceback.extract_tb(tb)[-1] #取得Call Stack的最後一筆資料
            fileName = lastCallStack[0] #取得發生的檔案名稱
            lineNum = lastCallStack[1] #取得發生的行號
            funcName = lastCallStack[2]#取得發生的函數名稱
            errMsg = f"{[error_class]}\n\"{fileName}\", line {lineNum}, in {funcName}\n{detail}"
            print('errMsg',errMsg)
            Global.UI_Signal.send_messagebox('Exception', errMsg, Global.UI_Type.critical.value)
    return warpper

@debug
def Main_Flow(file_path:str):
    print('in Main flow')
    row_data = Data_processing(file_path)
    if row_data:
        table_data = Second_processing(row_data)
        Global.UI_Signal.send_data(table_data)  

def Data_processing(file_path):
    with open(file_path, 'r') as f:
        data = f.read()
    COLUMN_data= data.split('$RCAD_ASCO COLUMN-LINE')
    if not len(COLUMN_data):
        Global.UI_Signal.send_messagebox('Warning', "匯入的資料並未找到'$RCAD_ASCO COLUMN-LINE'字串!", Global.UI_Type.warning.value)
        return False
    
    COLUMN_LINE_data= COLUMN_data[1:]
    row_data = dict() 
    linecount = 5  #每五行一個區塊
    for data in COLUMN_LINE_data:
        data_split = [c.strip() for c in data.split("\n") if c.strip() != '']
        title = data_split[0].strip("\"").strip("'")
        blockcount = int(data_split[1])
        start_ind = 2
        tmp_dict = dict()
        for _ in range(blockcount):
            tmp = [line.split() for line in data_split[start_ind : start_ind+linecount]]
            tmp = [list(map(convert, sublist)) for sublist in tmp]
            start_ind += linecount
            tmp_dict[tmp[0][0]] = deepcopy(tmp)
        
        row_data[title] = deepcopy(tmp_dict)
    return row_data

def convert(item):
    # 檢查 "數字#數字" 模式
    if re.match(r'^\d+#\d+$', item):
        return tuple(map(int, item.split('#')))

    # 檢查整數模式
    if re.match(r'^-?\d+$', item):
        return int(item)

    # 檢查浮點數模式
    if re.match(r'^-?\d+\.\d+$', item):
        float_val = float(item)
        if float_val.is_integer():
            return int(float_val)
        return float_val

    # 如果都不符合，保持原樣
    return item

def Second_processing(row_data:dict):
    table_data = dict()
    for name, data1 in row_data.items():
        tmp_list = list()
        for floor, data2 in data1.items():
            reinforcement = ((data2[2][0] + data2[3][0]) -4) *2 +4
            tmp = list(map(str, [floor, data2[1][0], data2[1][1], reinforcement, data2[1][2], data2[2][1], data2[3][1], data2[-1][-1]]))
            tmp_list.append(tmp)
        table_data[name] =  deepcopy(tmp_list)
    print(table_data)
    return table_data

if "__main__" == __name__:
    print(Main_Flow(file_path))