import sys
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QTableWidget, QTableWidgetItem, QVBoxLayout, 
    QWidget, QPushButton, QHBoxLayout, QComboBox, QFileDialog,  QSpacerItem, 
    QSizePolicy, QMessageBox
)
from PySide6.QtGui import QFont
from PySide6.QtCore import Qt, QThreadPool, QRunnable, Signal, QObject
from UI_Global import Global
from Main import Main_Flow

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.root_path = 'F:/Job'
        self.showdata = dict()
        self.Set_Window()
        self.threadpool = QThreadPool()
        self.threadpool.setMaxThreadCount(1)
    
    def Set_Window(self):
        self.setWindowTitle("PySide6 Table Example")
        self.resize(600, 400)
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.layout = QVBoxLayout(self.central_widget)

        self.Set_Top_layout()
        self.Set_Table_Widget()

    
    def Set_Top_layout(self):
        self.top_layout = QHBoxLayout()
        self.layout.addLayout(self.top_layout)
        self.top_layout.addWidget(self.Add_import_Btn())

        # 增加水平間隔
        spacer = QSpacerItem(400 ,QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.top_layout.addSpacerItem(spacer)

        self.top_layout.addWidget(self.Add_Combobox())

    def Add_import_Btn(self):
        self.import_button = QPushButton("Import")
        self.import_button.clicked.connect(self.open_file_dialog)
        return self.import_button
        
    def Add_Combobox(self):
        self.combo_box = QComboBox()
        self.combo_box.currentIndexChanged.connect(self.show_data)
        return self.combo_box

    def Set_Table_Widget(self):
        self.table = QTableWidget()
        self.setup_table()
        self.adjust_table_w()
        self.layout.addWidget(self.table)
        

    def setup_table(self):
        column_headers = ["樓層", "X向尺寸", "Y向尺寸", "配筋量", "As,req", "X向繫筋數", "Y向繫筋數", "中央圍束(剪力筋)"]
        self.table.setColumnCount(len(column_headers))
        self.table.setHorizontalHeaderLabels(column_headers)

        # 隱藏垂直表頭（行號）
        self.table.verticalHeader().setVisible(False)

        # 設置第一行的格式
        font = QFont("標楷體", 14, QFont.Bold)
        header_style = "QHeaderView::section { background-color: lightgray; }"
        self.table.horizontalHeader().setStyleSheet(header_style)
        for i in range(self.table.columnCount()):
            item = QTableWidgetItem(column_headers[i])
            item.setFont(font)
            item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)  # 設置為不可編輯
            self.table.setHorizontalHeaderItem(i, item)
         
    def adjust_table_w(self):
        # 調整每列的寬度以適應內容並計算總寬度
        total_width = 0
        extra_width = 10  # 每列增加的額外寬度
        for i in range(self.table.columnCount()):
            self.table.resizeColumnToContents(i)
            current_width = self.table.columnWidth(i) + extra_width
            self.table.setColumnWidth(i, current_width)
            total_width += current_width

        # 考慮邊框和一些額外空間
        total_width += self.table.verticalHeader().width()
        total_width += self.table.frameWidth() * 2
        total_width += 20  # 添加一些額外空間

        # 設置窗口寬度
        self.resize(total_width, self.height())

    def add_row(self, data:list):
        row = self.table.rowCount()
        self.table.insertRow(row)

        # 設置第一個單元格
        font_0 = QFont("Times New Roman", 12, QFont.Bold)
        
        first_item = QTableWidgetItem(data[0])
        first_item.setFont(font_0)
        first_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)  # 設置為不可編輯
        self.table.setItem(row, 0, first_item)

        # 設置其他單元格
        font = QFont("Times New Roman", 12)
        for i in range(1, len(data)):
            item = QTableWidgetItem(data[i])
            item.setFont(font)
            self.table.setItem(row, i, item)
            #self.table.openPersistentEditor(item) #不用點兩下表格就可以修改數據
    
    def clear_table(self):
        if self.table.rowCount() > 1:
            for _ in range(self.table.rowCount()):
                self.table.removeRow(0)
    
    def open_file_dialog(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "開啟檔案", self.root_path, "所有檔案 (*);;文字檔 (*.txt)")
        if file_name:
            self.root_path = file_name
            self.process_file(file_name)

    def process_file(self, file_path):
        self.worker = Worker(file_path)
        self.worker.signals.data.connect(self.data_processed)  # 處理返回的資料
        self.worker.signals.messagebox.connect(self.show_messagebox) 
        self.threadpool.start(self.worker)

    def data_processed(self, data:dict):
        self.showdata = data
        self.combo_list = list(data.keys())
        self.combo_box.addItems(self.combo_list)
    
    def show_data(self):
        self.clear_table()
        datas = self.showdata[self.combo_box.currentText()]
        for data in datas:
            self.add_row(data)
    
    def show_messagebox(self, info:tuple):
        title, message, message_type = info
        message_box_function = getattr(QMessageBox, message_type, QMessageBox.information)
        message_box_function(self, title, message)
        
class Worker(QRunnable):
    def __init__(self, file_path):
        super().__init__()
        self.signals = WorkerSignals()
        Global.UI_Signal.signal = self.signals
        self.file_path = file_path

    def run(self):
        Main_Flow(self.file_path)

class WorkerSignals(QObject):
    messagebox = Signal(tuple) #(title, content, type)
    data = Signal(object) 


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()

    #window.add_row(["1F", "10m", "8m", "200kg", "100cm²", "4", "4", "是"])
    window.show()
    sys.exit(app.exec())
